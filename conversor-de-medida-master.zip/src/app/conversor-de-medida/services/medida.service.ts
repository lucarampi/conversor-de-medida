import { Injectable } from '@angular/core';
import { Medida } from '../models';

@Injectable()
export class MedidaService {


}
