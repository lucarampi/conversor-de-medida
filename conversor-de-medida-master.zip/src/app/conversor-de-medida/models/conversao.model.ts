export class Conversao{
    constructor(public medidaDe?: string, public medidaPara?: string, public valor_entrada?: number, public valor_saida?: number){}
}