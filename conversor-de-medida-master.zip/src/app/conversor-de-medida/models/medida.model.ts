export class Medida{
    constructor(public value?:string,public sigla?: string, public descricao?: string){}
}